const days=[
["Arrive in Sound","Begin with one simple tone. Listen first. Then notice vibration and the space around it."],
["Follow the Tone","Stay with the tone from beginning to end. Notice texture without naming it."],
["Feel the Source","Notice where vibration is felt most clearly. Let sensation be enough."],
["See Vibration","Observe a cymatic image or physical surface responding to sound."],
["Sound and Breath","Let natural breathing coexist with the sound. Do not control or hold the breath."],
["Hand on Chest","Place one hand on the chest and listen. Notice contact, warmth and movement."],
["One Sound","Reduce the experience to one tone. Explore its changing presence."],
["The Silence","Notice the quiet before and after the sound. Silence becomes part of the experience."],
["Change Frequency","Move slowly between tones and observe how the visible pattern or felt quality changes."],
["First Resonance","Complete the first 10-day cycle. Let the experience settle without interpretation."],
["Longer Listening","Extend attention without forcing concentration."],["Vibration Map","Move attention through hands, chest, feet and surrounding space."],["Pattern and Form","Observe how geometry changes with the physical system."],["Tone and Touch","Combine listening with a steady, gentle hand contact."],["Sound in Space","Notice distance, direction and reflections."],["Stillness","Listen until the sound fades completely."],["Fine Detail","Attend to harmonics or small changes in texture."],["Embodied Presence","Stay with whole-body sensation while listening."],["Pattern Without Meaning","See the form before assigning a spiritual interpretation."],["Second Resonance","Complete Stage 2 and prepare for deeper exploration."],
["Acoustic Texture","Compare a pure tone with one natural acoustic source you select."],["Metal Resonance","If available, observe a safe struck metal object at a comfortable level."],["Bowl Resonance","If you choose a singing bowl, notice its complex harmonics rather than assuming one frequency."],["Voice","Explore a comfortable sustained vowel or hum; never force the voice."],["Water","Observe water responding to vibration if you have a suitable safe setup."],["Boundary","Notice how the container or surface shapes the pattern."],["Amplitude","Observe how changing volume alters a physical response; use safe levels."],["Frequency Sweep","Move gradually through a range and observe transitions."],["Return to Pure Tone","Use a single sine tone again as a controlled reference."],["Third Resonance","Complete Stage 3."],
["Listening","Let sound arrive without searching."],["Touch","Feel vibration through a safe contact point."],["Vision","Watch form emerge and disappear."],["Breath","Allow breathing to remain natural."],["Space","Notice the environment around the source."],["Silence","Rest between sounds."],["Rhythm","Observe repetition without adding music."],["Harmonics","Listen for overtones in an acoustic source."],["Form","Watch geometry change."],["Fourth Resonance","Complete Stage 4."],
["Slow Attention","Take the experience gradually."],["Near and Far","Notice perceived distance."],["Inside and Outside","Distinguish bodily sensation from external sound."],["Surface","Observe a vibrating surface if available."],["Medium","Compare water, sand or another safe medium visually."],["Geometry","Notice circular, radial or grid-like forms without claiming universality."],["Threshold","Observe when a pattern appears or disappears."],["Stability","Watch a stable pattern."],["Transition","Watch a pattern transform."],["Fifth Resonance","Complete Stage 5."],
["Pure Reference","Return to the pure tone reference."],["Acoustic Reference","Compare with your chosen acoustic source."],["Visual Reference","Compare visual response."],["Embodied Reference","Compare felt response without judging it."],["Quiet Reference","Spend equal time in silence."],["Attention","Notice where attention naturally goes."],["Choice","Choose the sound you want for today's experience."],["Presence","Stay with the chosen sound."],["Integration","Let hearing, seeing and feeling coexist."],["Sixth Resonance","Complete Stage 6."],
["Listening Deepens","Hear smaller details."],["Vibration Deepens","Feel subtle movement."],["Pattern Deepens","Watch finer geometry."],["Touch Deepens","Use gentle embodiment."],["Space Deepens","Notice reflections and room response."],["Silence Deepens","Remain present after sound stops."],["Frequency Deepens","Explore one carefully chosen range."],["Medium Deepens","Observe how the medium changes response."],["Resonance","Notice when the system responds strongly."],["Seventh Resonance","Complete Stage 7."],
["Observe","Observe before interpreting."],["Experience","Let experience precede explanation."],["Feel","Notice the felt sense."],["Embody","Allow sensation to be physically present."],["Become Coherent","Let attention gather naturally."],["Resonate","Stay with what resonates experientially."],["Expand","Include the surrounding space."],["Connect","Notice relationship between source, body and environment."],["Return Within","Return attention gently inward."],["Eighth Resonance","Complete Stage 8."],
["Sound as Event","Treat sound as an event, not a belief."],["Vibration as Process","Watch change rather than seeking a fixed result."],["Form as Response","Remember patterns depend on the physical system."],["Attention as Experience","Notice what attention highlights."],["Embodiment","Stay physically grounded."],["Acoustic Choice","Use the sound you selected."],["Visual Choice","Use the cymatic medium you selected."],["Silent Choice","End without sound."],["Integration","Bring the experience into an ordinary moment."],["Ninth Resonance","Complete Stage 9."],
["Begin Again","Return to the simplicity of one sound."],["Hear","Listen."],["Feel","Feel."],["See","See."],["Embody","Embody."],["Observe","Observe."],["Experience","Experience."],["Resonate","Resonate."],["Return","Return within."],["100-Day Completion","You have completed the 100-day experiential pathway. KEMP EYE 👁 now guides you toward your next experience."]
];
let day=Number(localStorage.getItem("kempCymaticsDay")||0);
let audio=null;
function stage(){return Math.floor(day/10)+1}
function render(){
 const d=days[day]; document.getElementById("stage").textContent=`STAGE ${stage()} · DAYS ${stage()*10-9}–${stage()*10}`;
 document.getElementById("day").textContent=`DAY ${day+1}`;document.getElementById("title").textContent=d[0];document.getElementById("guide").textContent=d[1];
 document.getElementById("aiTitle").textContent=day%10===9?"Stage complete — KEMP EYE 👁 Guidance":"Your next experience";
 document.getElementById("aiText").textContent=day%10===9?`You have reached Day ${day+1}. KEMP EYE 👁 opens the next 10-day stage. No data is sent anywhere.`:`When you finish today's experience, KEMP EYE 👁 carries you to Day ${day+2}.`;
 document.getElementById("status").textContent=`Day ${day+1} is ready.`;
 document.getElementById("stages").innerHTML=Array.from({length:10},(_,i)=>`<button class="stagebtn ${i===stage()-1?"active":""}" onclick="jump(${i*10})"><b>STAGE ${i+1}</b><small>Days ${i*10+1}–${i*10+10}</small></button>`).join("");
}
window.jump=i=>{day=i;localStorage.setItem("kempCymaticsDay",day);render();scrollTo({top:0,behavior:"smooth"})};
const freq=document.getElementById("freq"),hz=document.getElementById("hzLabel");
freq.oninput=()=>hz.textContent=`${freq.value} Hz`;
document.getElementById("sound").onclick=()=>{
 if(audio){audio.stop();audio=null;document.getElementById("sound").textContent="▶ Play test tone";return}
 const C=window.AudioContext||window.webkitAudioContext; audio=C?new C():null;
 if(!audio)return;
 const o=audio.createOscillator(),g=audio.createGain();o.type="sine";o.frequency.value=Number(freq.value);g.gain.value=.04;o.connect(g).connect(audio.destination);o.start();audio.osc=o;audio.stop=()=>{try{o.stop()}catch(e){};audio.close?.()};document.getElementById("sound").textContent="■ Stop test tone";
};
document.getElementById("continue").onclick=()=>{
 if(audio){audio.stop();audio=null;document.getElementById("sound").textContent="▶ Play test tone"}
 if(day<99){day++;localStorage.setItem("kempCymaticsDay",day);render();scrollTo({top:0,behavior:"smooth"})}
 else {document.getElementById("status").textContent="100 days complete — KEMP EYE 👁 guidance is now open."}
};
if("serviceWorker" in navigator)navigator.serviceWorker.register("sw.js");
let dp;addEventListener("beforeinstallprompt",e=>{e.preventDefault();dp=e;document.getElementById("install").hidden=false});
document.getElementById("install").onclick=async()=>{if(dp){dp.prompt();await dp.userChoice;dp=null}};
render();
